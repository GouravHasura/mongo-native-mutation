# MongoDB Mutation Generator

This tool generates MongoDB mutation files for Hasura DDN based on schema definitions.

## Setup

This project uses `uv` for Python package management. No external dependencies are required.

### Setup with uv

```bash
# Create a virtual environment
uv venv

# Activate the virtual environment
source .venv/bin/activate  # On Linux/Mac
# or
.venv\Scripts\activate     # On Windows
```

## Usage

```bash
# Generate mutations with default settings
python -m scripts.mongo_mutations.mutations

# Generate mutations with custom directories
python -m scripts.mongo_mutations.mutations --schema-dir path/to/schema --output-dir path/to/output

# Generate mutations with verbose output
python -m scripts.mongo_mutations.mutations --verbose
```

## Command Line Options

- `--schema-dir`: Directory containing schema JSON files (default: "app/connector/mongo/schema")
- `--output-dir`: Directory to save generated mutation files (default: "app/connector/mongo/native_mutations")
- `--verbose`: Enable verbose output

## Generated Mutations

For each collection defined in the schema files, the following mutation files are generated:

1. `insert<Collection>`: Insert a single document
2. `update<Collection>ById`: Update a document by ID with individual field arguments
3. `update<Collection>`: Update documents with flexible filtering and extendedJSON update operations
4. `delete<Collection>ById`: Delete a document by ID
5. `delete<Collection>`: Delete documents with flexible filtering and field name mapping

### Update Mutation Types

**`update<Collection>ById`**: Traditional field-by-field updates
- Takes an `id` argument and individual field arguments
- Uses `$set` operations for each provided field
- Simple and type-safe for basic updates

**`update<Collection>`**: Flexible updates with MongoDB operations
- Takes a `filter` argument (any combination of collection fields)
- Takes an `update` argument as extendedJSON (raw MongoDB update document)
- Supports complex MongoDB operations like `$set`, `$unset`, `$inc`, `$push`, etc.
- Enables nested field updates, array operations, and atomic operations

### Delete Mutation Types

**`delete<Collection>ById`**: Delete a single document by ID
- Takes an `id` argument (ObjectId)
- Deletes exactly one document matching the ID
- Simple and efficient for single document deletion

**`delete<Collection>`**: Flexible delete with filtering and field name mapping
- Takes a `filter` argument (any combination of collection fields)
- Supports field name variations (snake_case, camelCase, PascalCase)
- Can delete multiple documents matching the filter criteria
- Automatically maps field names to handle different naming conventions

Note: The `insertMany<Collection>`, `updateMany<Collection>`, and `deleteMany<Collection>` mutations have been removed due to limitations with field name mapping and to simplify the API.

### Usage Examples

**Traditional update by ID:**
```json
{
  "updateArtistsById": {
    "id": "507f1f77bcf86cd799439011",
    "name": "Updated Artist Name"
  }
}
```

**Flexible update with filtering:**
```json
{
  "updateArtists": {
    "filter": { "ArtistId": 123 },
    "update": { "$set": { "Name": "New Artist Name" } }
  }
}
```

**Complex nested updates:**
```json
{
  "updateSysCnfg": {
    "filter": { "applNm": "prism_member_banner_widget" },
    "update": {
      "$set": {
        "cnfgVal.additionalDrawerBehaviour": "modal",
        "cnfgVal.cbmsCallEnabled": true
      }
    }
  }
}
```

**Atomic operations:**
```json
{
  "updateSysCnfg": {
    "filter": { "applNm": "care_plan" },
    "update": {
      "$inc": {
        "cnfgVal.goalType.shortTerm": 1,
        "cnfgVal.goalType.longTerm": 2
      }
    }
  }
}
```

**Delete by ID:**
```json
{
  "deleteAlbumsById": {
    "id": "507f1f77bcf86cd799439011"
  }
}
```

**Delete with filtering:**
```json
{
  "deleteAlbums": {
    "filter": { "ArtistId": 123 }
  }
}
```

**Delete with field name variations:**
```json
{
  "deleteAlbums": {
    "filter": { "artist_id": 123 }  // snake_case
  }
}
```

```json
{
  "deleteAlbums": {
    "filter": { "artistId": 123 }  // camelCase
  }
}
```

## Schema Structure

The tool expects schema files in the following format:

```json
{
  "name": "CollectionName",
  "collections": {
    "CollectionName": {
      "type": "CollectionName"
    }
  },
  "objectTypes": {
    "CollectionName": {
      "fields": {
        "field1": {
          "type": {
            "scalar": "string"
          }
        },
        "field2": {
          "type": {
            "nullable": {
              "scalar": "int"
            }
          }
        },
        "_id": {
          "type": {
            "scalar": "objectId"
          }
        }
      }
    }
  }
}
```
