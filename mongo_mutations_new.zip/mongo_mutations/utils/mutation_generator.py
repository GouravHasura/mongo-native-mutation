"""
Functions for generating MongoDB mutation files.
"""
from typing import Dict, Any, List


def generate_all_mutations_for_collection(collection_info: Dict[str, Any], output_dir: str) -> List[str]:
    """
    Generate all mutation files for a collection.

    Args:
        collection_info: Collection information dictionary
        output_dir: Directory to save the mutation files

    Returns:
        List of paths to the generated files
    """
    generated_files = []

    # Generate insert mutations
    from scripts.mongo_mutations.utils.insert_mutation_generator import generate_insert_mutation
    generated_files.append(generate_insert_mutation(collection_info, output_dir))

    # Generate update_by_pk mutations
    from scripts.mongo_mutations.utils.update_mutation_generator import generate_update_by_pk_mutation, generate_flexible_update_mutation
    generated_files.append(generate_update_by_pk_mutation(collection_info, output_dir))

    # Generate flexible update mutations
    generated_files.append(generate_flexible_update_mutation(collection_info, output_dir))

    # Generate delete_by_pk mutations
    from scripts.mongo_mutations.utils.delete_mutation_generator import generate_delete_by_pk_mutation, generate_flexible_delete_mutation
    generated_files.append(generate_delete_by_pk_mutation(collection_info, output_dir))

    # Generate flexible delete mutations
    generated_files.append(generate_flexible_delete_mutation(collection_info, output_dir))

    # Generate config-based update mutations
    from scripts.mongo_mutations.utils.config_update_mutation_generator import generate_all_config_based_mutations
    config_based_files = generate_all_config_based_mutations(collection_info, output_dir)
    generated_files.extend(config_based_files)

    return generated_files
