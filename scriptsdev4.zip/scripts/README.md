# MongoDB Mutation Generator

This script generates TypeScript mutation functions and types for MongoDB collections based on Hasura DDN schema JSON files.

## Usage

```bash
cd scripts
npx tsx generate-mutations.ts <schema-directory> <output-file> [mongodb-uri-env-var]
```

### Examples

```bash
# Using default environment variable name (MONGODB_URI)
npx tsx generate-mutations.ts ../app/connector/mongo/schema ../app/connector/mongots/functions.ts

# Using custom environment variable name
npx tsx generate-mutations.ts ../app/connector/mongo/schema ../app/connector/mongots/functions.ts APP_MONGO_MONGODB_DATABASE_URI
```

**Note**: The database name should be included in the MongoDB URI (e.g., `mongodb://user:pass@host:port/database_name`). The script will extract it automatically.

## What it generates

For each MongoDB collection, the script generates:

1. **TypeScript interfaces** for all object types
2. **Filter types** (`<CollectionName>Filter`) - for equality filtering on top-level fields
3. **Insert types** (`<CollectionName>Insert`) - for document insertion (excludes `_id`)
4. **Update types** (`<CollectionName>Update`) - for document updates (all fields optional)
5. **Delete types** (`<CollectionName>Delete`) - standard MongoDB delete response
6. **Mutation functions**:
   - `insert<CollectionName>(documents: <CollectionName>Insert[]): Promise<{ insertedIds: string[] }>`
   - `update<CollectionName>(filter: <CollectionName>Filter, updates: <CollectionName>Update[]): Promise<{ modifiedCount: number }>`
   - `delete<CollectionName>(filter: <CollectionName>Filter): Promise<<CollectionName>Delete>`

## Supported MongoDB Types

The script supports all MongoDB scalar types with proper Hasura NDC SDK type mapping:

### ✅ **Fully Compatible Types:**
- `string`, `uuid`, `objectId`, `javascript`, `javascriptWithScope` → `string`
- `int`, `long`, `double`, `decimal`, `float` → `number`
- `bool`, `boolean` → `boolean`
- `date`, `timestamp` → `string` (MongoDB typically stores dates as ISO strings)

### ⚠️ **Converted to sdk.JSONValue (for compatibility):**
- `extendedJSON` → `sdk.JSONValue` (arbitrary JSON data)
- `null` → `sdk.JSONValue` (standalone null not supported)
- `undefined` → `sdk.JSONValue` (standalone undefined not supported)
- `binData` → `sdk.JSONValue` (avoid complex Buffer unions)
- `regex` → `sdk.JSONValue` (avoid RegExp unions)
- `minKey`, `maxKey`, `dbPointer`, `symbol` → `sdk.JSONValue`

### 🔧 **Automatic Type Validation:**
- Complex unions (e.g., `string | Date`) → `sdk.JSONValue`
- Multi-unions (more than 2 types) → `sdk.JSONValue`
- Only `type | null` and `type | undefined` unions are preserved

## Implementation

The generated functions include complete MongoDB implementations with:

1. **Connection pooling/memoization** - Reuses MongoDB connections across function calls for better performance
2. **Environment variable support** - Requires `MONGODB_URI` and `MONGODB_DB` environment variables
3. **Comprehensive error handling** - Uses Hasura NDC SDK error classes for proper GraphQL error responses
4. **OpenTelemetry tracing** - All operations are wrapped with spans for observability
5. **Type-safe operations** - All parameters and return types are properly typed
6. **ObjectId handling** - Properly converts string IDs to MongoDB ObjectIds using non-deprecated methods

## Environment Variables

Set the MongoDB URI environment variable for the functions to work:

```bash
# Default environment variable name
MONGODB_URI=mongodb://user:pass@host:port/database_name

# Or your custom environment variable (as specified in script parameters)
APP_MONGO_MONGODB_DATABASE_URI=mongodb://codedmart:pass@local.hasura.dev:27018/optummut?authSource=admin
```

**Important**: The database name must be included in the MongoDB URI path. The script will extract it automatically and throw an error if it's missing.

## Features

- **Quoted field names**: Fields with special characters (like `driver-class-name`) are properly quoted
- **Complete implementations**: No TODO comments - functions are ready to use
- **Connection pooling**: Shared MongoDB connection across all function calls
- **Bulk operations**: Insert and update functions support arrays for efficient bulk operations
- **Proper error handling**: Uses `sdk.UnprocessableContent`, `sdk.Conflict`, etc. for GraphQL-friendly errors
- **OpenTelemetry tracing**: Each operation creates spans with relevant attributes for monitoring
- **ObjectId conversion**: Safely converts string `_id` values to MongoDB ObjectIds
- **Hasura NDC SDK types**: Uses `sdk.JSONValue` for complex/arbitrary JSON data instead of `any`
- **Union type compliance**: Only uses union types with `null` or `undefined` (e.g., `string | null`) as required by Hasura NDC
- **Automatic date conversion**: Converts ISO date strings to proper MongoDB Date objects for storage

## Error Handling

The functions use Hasura NDC SDK error classes:

- `sdk.UnprocessableContent` - For validation errors, missing data, invalid ObjectIds
- `sdk.Conflict` - For duplicate key violations
- Includes error details and stack traces in OpenTelemetry spans (not exposed to GraphQL clients)

## Tracing

All mutation functions are wrapped with OpenTelemetry spans:

- Span names: `insert_<CollectionName>`, `update_<CollectionName>`, `delete_<CollectionName>`
- Attributes include: collection name, operation type, document/update counts, filters
- Tracer name: `mongodb-mutations`
